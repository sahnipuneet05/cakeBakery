<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Cake Bakery')); ?></title>
    <link href="assets/auth/register/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
    <link href="assets/auth/register/css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link href="//fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Josefin+Sans:400,600,700" rel="stylesheet">
        
</head>
<body>
	<div class="mian-content">
		<!-- header -->
		<?php echo $__env->yieldContent('content'); ?>
	</div>
	<?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Puneet\cakebakery\resources\views/layouts/auth/register/register.blade.php ENDPATH**/ ?>