
<?php $__env->startSection('content'); ?>
<div class="banner2-w3ls">

</div>
<div class="breadcrumb-agile">
		<nav aria-label="breadcrumb">
			<ol class="breadcrumb m-0">
				<li class="breadcrumb-item">
					<a href="index.html">Home</a>
				</li>
				<li class="breadcrumb-item active" aria-current="page">Contact Us</li>
			</ol>
		</nav>
	</div>
	<!-- //page details -->

	<!-- contact page -->
	<div class="address py-5">
		<div class="container py-xl-5 py-lg-3">
			<div class="title text-center mb-5">
				<h2 class="text-dark mb-2">Contact Us</h2>

			</div>
			<div class="row address-row">
				<div class="col-lg-6 address-right">
					<div class="address-info wow fadeInRight animated" data-wow-delay=".5s">
						<h4 class="font-weight-bold mb-3">Address</h4>
						<p>#1142, SWIFT ROAD , LONDON .</p>
					</div>
					<div class="address-info address-mdl wow fadeInRight animated" data-wow-delay=".7s">
						<h4 class="font-weight-bold mb-3">Phone </h4>
						<p>+164 221 325</p>
						<p>+164 221 3354</p>
					</div>
					<div class="address-info agileits-info wow fadeInRight animated" data-wow-delay=".6s">
						<h4 class="font-weight-bold mb-3">Mail</h4>
						<p>
							<a href="mailto:example@mail.com">cakebakery123@gmail.com</a>
						</p>

					</div>
				</div>
				<div class="col-lg-6 address-left mt-lg-0 mt-5">
					<div class="address-grid">
						<h4 class="font-weight-bold mb-3">Get In Touch</h4>
						<form action="#" method="post">
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Name" name="name" required="">
							</div>
							<div class="form-group">
								<input type="email" class="form-control" placeholder="Email" name="email" required="">
							</div>
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Subject" name="subject" required="">
							</div>
							<div class="form-group">
								<textarea placeholder="Message" class="form-control" required=""></textarea>
							</div>
							<input type="submit" value="SEND">
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>			
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cakebakery\cakebakery\resources\views/home/contact-us.blade.php ENDPATH**/ ?>