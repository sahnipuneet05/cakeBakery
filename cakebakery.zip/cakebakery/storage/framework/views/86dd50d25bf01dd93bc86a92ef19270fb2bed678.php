
<?php $__env->startSection('content'); ?>
<div id="slider-main">
	<div class="banner-text-agile text-center">
		<div class="container">
			<br>
			<h3 class="text-white font-weight-bold mb-3">The Taste Of Our Amazing Cakes</h3>

		</div>
	</div>
	<!-- previous button -->
	<button id="prev">
		<i class="fas fa-chevron-left"></i>
	</button>
	<!-- image container -->
	<div id="slider"></div>
	<!-- next button -->
	<button id="next">
		<i class="fas fa-chevron-right"></i>
	</button>
	<!-- small circles container -->
	<div id="circles"></div>
</div>
<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title text-center" id="exampleModalCenterTitle">Cake Bakery</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body p-0">
				<iframe src="https://player.vimeo.com/video/58582025" style="border:none"></iframe>
			</div>
		</div>
	</div>
</div>
		<!-- //Model -->
		<!-- //banner -->

		<!-- banner bottom icons -->
<div class="icons-banner-botom">
	<div class="container">
		<ul class="list-unstyled my-4">
			<li class="icons-mkw3ls">
				<p class="mb-2">Chocolate</p>
				<img src="assets/images/img1.png" class="img-fluid" alt="">
			</li>
			<li class="icons-mkw3ls">
				<p class="mb-2">Strawberry</p>
				<img src="assets/images/img2.png" class="img-fluid" alt="">
			</li>
			<li class="icons-mkw3ls">
				<p class="mb-2">Pista</p>
				<img src="assets/images/img3.png" class="img-fluid" alt="">
			</li>
			<li class="icons-mkw3ls">
				<p class="mb-2">Vanilla</p>
				<img src="assets/images/img4.png" class="img-fluid" alt="">
			</li>
			<li class="icons-mkw3ls">
				<p class="mb-2">Muffins</p>
				<img src="assets/images/img5.png" class="img-fluid" alt="">
			</li>
		</ul>
	</div>
</div>
		<!-- //banner bottom icons -->
	
	<!-- //main -->

	<!-- banner-bottom -->
<section class="banner-main-agiles py-5">
	<div class="banner-bottom-w3layouts" id="about">
		<div class="container pt-xl-5 pt-lg-3">
			<div class="row mt-5">
				<div class="col-lg-6">
					<p class="text-uppercase">A few words</p>
					<h3 class="aboutright">Welcome to Pretty Cakes Bakery of London </h3>
					<h4 class="aboutright">Where fabulous flavours and wonderful designs go hand and hand withe a friendly and professional service</h4>
					<p>Our recipes, using only quality imgredients and traditional method, have been tried, tested and perfected.
						These wonderfully unique cakes will guarantee to make your event extra- special.
						</p>

				</div>
				<div class="col-lg-6 about-img text-lg-enter">
					<img src="assets/images/about.png" alt="" class="img-fluid">
				</div>
			</div>
		</div>


	</div>
	<!-- //banner-bottom-w3layouts -->
	<div class="some-another text-center pb-5">
		<div class="container pb-xl-5 pb-lg-3">
			<i class="fas fa-utensils"></i>
			<p class="text-uppercase mb-4 mt-2">Cakes Bakery Restaurants</p>
			<h4 class="aboutright about-right-2">Great baking brings joy and we believe in making people smile and happy at every occasion
			</h4>
			<h5 class="text-uppsecase font-weight-bold text-dark mt-4">Chloe Jack
				<span class="text-secondary font-weight-normal">(Master Chef)</span>
			</h5>
		</div>
	</div>
	<!-- cake -->
	<img src="assets/images/cake7.png" alt="" class="img-fluid cake-style">

	<!-- //cake -->
</section>

	<!-- services -->
<div class="serives-agile py-5 bg-light border-top" id="services">
	<div class="container py-xl-5 py-lg-3">
		<div class="row support-bottom text-center">
			<div class="col-md-4 support-grid">
				<i class="far fa-heart"></i>
				<h5 class="text-dark text-uppercase mt-4 mb-3">Made With Love</h5>
				<p>Ut enim ad minima veniam, quis nostrum ullam corporis suscipit laboriosam.</p>
			</div>
			<div class="col-md-4 support-grid my-md-0 my-4">
				<i class="fas fa-birthday-cake"></i>
				<h5 class="text-dark text-uppercase mt-4 mb-3">Seasonal Pastries</h5>
				<p>Ut enim ad minima veniam, quis nostrum ullam corporis suscipit laboriosam.</p>
			</div>
			<div class="col-md-4 support-grid">
				<i class="far fa-calendar"></i>
				<h5 class="text-dark text-uppercase mt-4 mb-3">Event Catering</h5>
				<p>Ut enim ad minima veniam, quis nostrum ullam corporis suscipit laboriosam.</p>
			</div>
		</div>
	</div>
</div>
	<!-- //services -->

	<!-- stats section -->
<div class="middlesection-agile ">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 text-lg-left text-center pt-4">
				<img src="assets/images/women.png" alt="" class="img-fluid women-style" />
			</div>
			<div class="col-lg-6 left-build-wthree aboutright-agilewthree mt-0 py-5">
				<div class=" py-xl-5 py-lg-3">
					<h2 class="title-2 text-white mb-sm-5 mb-4">Some Statistical Facts</h2>
					<div class="row mb-xl-5 mb-4">
						<div class="col-4 w3layouts_stats_left w3_counter_grid">
							<p class="counter">1680</p>
							<p class="para-text-w3ls text-light">Popularity</p>
						</div>
						<div class="col-4 w3layouts_stats_left w3_counter_grid2">
							<p class="counter">1200</p>
							<p class="para-text-w3ls text-light">Happy Customers</p>
						</div>
						<div class="col-4 w3layouts_stats_left w3_counter_grid1">
							<p class="counter">400</p>
							<p class="para-text-w3ls text-light">Awards Won</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
	<!-- //stats section -->

	<!-- new products -->
<div class="featured-section py-5" id="products">
	<div class="container py-xl-5 py-lg-3">
		<div class="title text-center mb-5">
			<h3 class="text-dark mb-2">New Products</h3>
			<p>Ut enim ad minim veniam, quis nostrud ullam.</p>
		</div>
		<div class="content-bottom-in">
			<ul id="flexiselDemo1">
				<li>
					<div class="w3l-specilamk">
						<div class="row">
							<div class="col-lg-6 product-name-w3l">
								<h4 class="font-weight-bold">Strawberry Cakes</h4>
								<p class="dont-inti-w3ls mt-4 mb-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
									accuslaudantium.</p>
								<p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto vitae dicta sunt explicabo, Sed ut
									perspiciatis
									unde omnis iste natus error sit voluptatem accuslaudantium.</p>
								<a href="#order" class="button-3 active mt-5 py-4 scroll">Order Now</a>
							</div>
							<div class="col-lg-6 speioffer-agile">
								<img src="assets/images/product1.jpg" alt="" class="img-fluid">
							</div>
						</div>
					</div>
				</li>
				<li>
					<div class="w3l-specilamk">
						<div class="row">
							<div class="col-lg-6 product-name-w3l">
								<h4 class="font-weight-bold">Dessert Cakes</h4>
								<p class="dont-inti-w3ls mt-4 mb-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
									accuslaudantium.</p>
								<p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto vitae dicta sunt explicabo, Sed ut
									perspiciatis
									unde omnis iste natus error sit voluptatem accuslaudantium.</p>
								<a href="#order" class="button-3 active mt-5 py-4 scroll">Order Now</a>
							</div>
							<div class="col-lg-6 speioffer-agile">
								<img src="assets/images/product2.jpg" alt="" class="img-fluid">
							</div>
						</div>
					</div>
				</li>
				<li>
					<div class="w3l-specilamk">
						<div class="row">
							<div class="col-lg-6 product-name-w3l">
								<h4 class="font-weight-bold">Vanilla Cakes</h4>
								<p class="dont-inti-w3ls mt-4 mb-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
									accuslaudantium.</p>
								<p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto vitae dicta sunt explicabo, Sed ut
									perspiciatis
									unde omnis iste natus error sit voluptatem accuslaudantium.</p>
								<a href="#order" class="button-3 active mt-5 py-4 scroll">Order Now</a>
							</div>
							<div class="col-lg-6 speioffer-agile">
								<img src="assets/images/product3.jpg" alt="" class="img-fluid">
							</div>
						</div>
					</div>
				</li>
				<li>
					<div class="w3l-specilamk">
						<div class="row">
							<div class="col-lg-6 product-name-w3l">
								<h4 class="font-weight-bold">Roller Coaster</h4>
								<p class="dont-inti-w3ls mt-4 mb-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
									accuslaudantium.</p>
								<p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto vitae dicta sunt explicabo, Sed ut
									perspiciatis
									unde omnis iste natus error sit voluptatem accuslaudantium.</p>
								<a href="#order" class="button-3 active mt-5 py-4 scroll">Order Now</a>
							</div>
							<div class="col-lg-6 speioffer-agile">
								<img src="assets/images/product4.jpg" alt="" class="img-fluid">
							</div>
						</div>
					</div>
				</li>
				<li>
					<div class="w3l-specilamk">
						<div class="row">
							<div class="col-lg-6 product-name-w3l">
								<h4 class="font-weight-bold">Chocolate Cakes</h4>
								<p class="dont-inti-w3ls mt-4 mb-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
									accuslaudantium.</p>
								<p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto vitae dicta sunt explicabo, Sed ut
									perspiciatis
									unde omnis iste natus error sit voluptatem accuslaudantium.</p>
								<a href="#order" class="button-3 active mt-5 py-4 scroll">Order Now</a>
							</div>
							<div class="col-lg-6 speioffer-agile">
								<img src="assets/images/product5.jpg" alt="" class="img-fluid">
							</div>
						</div>
					</div>
				</li>
			</ul>
		</div>
	</div>
</div>
	<!-- //new products	-->

	<!-- news -->
<div class="news-agile bg-cream py-5" id="news">
	<div class="container py-xl-5 py-lg-3">
		<div class="row">
			<!-- order form -->
			<div class="col-lg-4 order-form-w3ls pl-lg-0" id="order">
				<div class="agile_its_registration bg-white">
					<h3 class="title-2 mb-3">Order a Cake</h3>

					<form action="<?php echo e(route('order-store')); ?>" method="post">
						<?php echo csrf_field(); ?>
						<div class="agileits-location form-group">
							<label>Ingredients</label>
							<select required name="ingredients">
								<option value="Baking powder">Baking powder</option>
								<option value="All purpose flour">All purpose flour</option>
								<option value="chocolate chip">chocolate chip</option>
								<option value="Cocoa powder">Cocoa powder</option>
								<option value="Unsalted butter">Unsalted butter</option>
								<option value="vanilla extract">vanilla extract</option>
								<option value="brownie">brownie</option>
								<option value="Cream cheese">Cream cheese</option>
								<option value="Scores">Scores</option>
								<option value="whipping cream">whipping cream</option>
								<option value="whole milk">whole milk</option>
							</select>
							<div class="clear"></div>
						</div>
						<div class="agileits-location w3ls-1 form-group">
							<label>quantity</label>
							<select required name="quantity">
								<option value="1lb">1lb</option>
								<option value="2lb">2lb</option>
								<option value="3lb">3lb</option>
								<option value="4lb">4lb</option>
								<option value="5lb">5lb</option>
								<option value="6lb">6lb</option>
								<option value="1ltr">1ltr</option>
								<option value="2ltr">2ltr</option>
								<option value="3ltr">3ltr</option>
								<option value="4ltr">4ltr</option>
							</select>
							<div class="clear"></div>
						</div>
						<div class="agileits-location form-group">
							<div class="clear"></div>
						</div>
						<div class="agileits-location w3ls-1 form-group">
							<label>Flavor</label>
							<select required name="flavor">
								<option value="Chocolate">Chocolate</option>
								<option value="Butterscotch">Butterscotch </option>
								<option value="Strawberry">Strawberry</option>
								<option value="Vanilla">Vanilla</option>
							</select>
							<div class="clear"></div>
						</div>
						<input type="submit" href="order/index.html" value="Order" class="agileinfo-order btn" />
					</form>
				</div>
			</div>
			<!-- //order form -->
			<!-- news -->
			<div class="col-lg-8 news-blog mt-lg-0 mt-5">
				<h3 class="title-2 mb-md-5 mb-4">Cakes Bakery </h3>
				<div class="row">
					<div class="col-sm-6 news-grids-agile">
						<div class="news-top">
							<a href="single.html">
								<img src="assets/images/news1.jpg" alt="" class="img-fluid" />
							</a>
						</div>
						<div class="price-bottom bg-white p-4">
							<a href="single.html" class="text-dark">March 11st, 2021</a>
							<h5 class="mt-3">children birthday party</h5>
						</div>
					</div>
					<div class="col-sm-6 news-grids-agile mt-sm-0 mt-5">
						<div class="news-top">
							<a href="single.html">
								<img src="assets/images/news2.jpg" alt="" class="img-fluid" />
							</a>
						</div>
						<div class="price-bottom bg-white p-4">
							<a href="single.html" class="text-dark">March 15st, 2021</a>
							<h5 class="mt-3">valentine party cake </h5>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>			
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Puneet\cakebakery\resources\views/home/index.blade.php ENDPATH**/ ?>