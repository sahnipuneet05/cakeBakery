<meta name="keywords" content="Cakes Bakery Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script>
	addEventListener("load", function () {
		setTimeout(hideURLbar, 0);
	}, false);

	function hideURLbar() {
		window.scrollTo(0, 1);
	}
</script>
<!-- //Meta tag Keywords -->

<!-- Custom-Files -->
<link rel="stylesheet" href="assets/css/bootstrap.css">
<!-- Bootstrap-Core-CSS -->
<link href="assets/css/login_overlay.css" rel='stylesheet' type='text/css' />

<link rel="stylesheet" href="assets/css/style.css" type="text/css" media="all" />
<!-- Style-CSS -->
<link rel="stylesheet" href="assets/css/fontawesome-all.css">

<link rel="stylesheet" type="text/css" href="assets/css/image-slider.css">
<!-- Font-Awesome-Icons-CSS -->
<!-- //Custom-Files -->

<!-- Web-Fonts -->
<link href="//fonts.googleapis.com/css?family=Oxygen:300,400,700&amp;subset=latin-ext" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
    rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Pacifico&amp;subset=cyrillic,latin-ext,vietnamese" rel="stylesheet">
<!-- //Web-Fonts --><?php /**PATH C:\xampp\htdocs\cakebakery\cakebakery\resources\views/layouts/head.blade.php ENDPATH**/ ?>