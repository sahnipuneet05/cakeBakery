
<?php $__env->startSection('content'); ?>
<div class="banner2-w3ls">

</div>
<div class="breadcrumb-agile">
		<nav aria-label="breadcrumb">
			<ol class="breadcrumb m-0">
				<li class="breadcrumb-item">
					<a href="index.html">Home</a>
				</li>
				<li class="breadcrumb-item active" aria-current="page">Gallery</li>
			</ol>
		</nav>
	</div>
	<!-- //page details -->

	<!-- gallery page -->
	<div class="gallery py-5">
		<div class="container py-xl-5 py-lg-3">
			<div class="title text-center mb-5">
				<h2 class="text-dark mb-2">Gallery</h2>

			</div>
			<div class="row w3ls_portfolio_grids">
				<div class="col-sm-4 agileinfo_portfolio_grid">
					<div class="w3_agile_portfolio_grid1">
						<a href="images/g1.jpg" title="Cakes Bakery">
							<div class="agileits_portfolio_sub_grid agileits_w3layouts_team_grid">
								<div class="w3layouts_port_head">
									<h3>Cakes Bakery</h3>
								</div>
								<img src="assets/images/g1.jpg" alt=" " class="img-fluid" />
							</div>
						</a>
					</div>
					<div class="w3_agile_portfolio_grid1">
						<a href="images/g2.jpg" title="Cakes Bakery">
							<div class="agileits_portfolio_sub_grid agileits_w3layouts_team_grid">
								<div class="w3layouts_port_head">
									<h3>Cakes Bakery</h3>
								</div>
								<img src="assets/images/g2.jpg" alt=" " class="img-fluid" />
							</div>
						</a>
					</div>
					<div class="w3_agile_portfolio_grid1">
						<a href="images/g3.jpg" title="Cakes Bakery">
							<div class="agileits_portfolio_sub_grid agileits_w3layouts_team_grid">
								<div class="w3layouts_port_head">
									<h3>Cakes Bakery</h3>
								</div>
								<img src="assets/images/g3.jpg" alt=" " class="img-fluid" />
							</div>
						</a>
					</div>
				</div>
				<div class="col-sm-4 agileinfo_portfolio_grid">
					<div class="w3_agile_portfolio_grid1">
						<a href="images/g4.jpg" title="Cakes Bakery">
							<div class="agileits_portfolio_sub_grid agileits_w3layouts_team_grid">
								<div class="w3layouts_port_head">
									<h3>Cakes Bakery</h3>
								</div>
								<img src="assets/images/g4.jpg" alt=" " class="img-fluid" />
							</div>
						</a>
					</div>
					<div class="w3_agile_portfolio_grid1">
						<a href="images/g5.jpg" title="Cakes Bakery">
							<div class="agileits_portfolio_sub_grid agileits_w3layouts_team_grid">
								<div class="w3layouts_port_head">
									<h3>Cakes Bakery</h3>
								</div>
								<img src="assets/images/g5.jpg" alt=" " class="img-fluid" />
							</div>
						</a>
					</div>
					<div class="w3_agile_portfolio_grid1">
						<a href="images/g6.jpg" title="Cakes Bakery">
							<div class="agileits_portfolio_sub_grid agileits_w3layouts_team_grid">
								<div class="w3layouts_port_head">
									<h3>Cakes Bakery</h3>
								</div>
								<img src="assets/images/g6.jpg" alt=" " class="img-fluid" />
							</div>
						</a>
					</div>
				</div>
				<div class="col-sm-4 agileinfo_portfolio_grid">
					<div class="w3_agile_portfolio_grid1">
						<a href="images/g7.jpg" title="Cakes Bakery">
							<div class="agileits_portfolio_sub_grid agileits_w3layouts_team_grid">
								<div class="w3layouts_port_head">
									<h3>Cakes Bakery</h3>
								</div>
								<img src="assets/images/g7.jpg" alt=" " class="img-fluid" />
							</div>
						</a>
					</div>
					<div class="w3_agile_portfolio_grid1">
						<a href="images/g8.jpg" title="Cakes Bakery">
							<div class="agileits_portfolio_sub_grid agileits_w3layouts_team_grid">
								<div class="w3layouts_port_head">
									<h3>Cakes Bakery</h3>
								</div>
								<img src="assets/images/g8.jpg" alt=" " class="img-fluid" />
							</div>
						</a>
					</div>
					<div class="w3_agile_portfolio_grid1">
						<a href="images/g9.jpg" title="Cakes Bakery">
							<div class="agileits_portfolio_sub_grid agileits_w3layouts_team_grid">
								<div class="w3layouts_port_head">
									<h3>Cakes Bakery</h3>
								</div>
								<img src="assets/images/g9.jpg" alt=" " class="img-fluid" />
							</div>
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>			
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Puneet\cakebakery\resources\views/home/gallery.blade.php ENDPATH**/ ?>